sap.ui.define([
	"tutorialspoint/attachChange/test/unit/controller/View1.controller"
], function () {
	"use strict";
});